:- dynamic xylast/3.

xylast(1, 20, 20).

:- dynamic angle/1.

angle(90).

:- dynamic active/1.

active(1).

:- dynamic xy/3.

xy(1, 50.0, 50.0).
xy(1, 20.0, 20.0).

